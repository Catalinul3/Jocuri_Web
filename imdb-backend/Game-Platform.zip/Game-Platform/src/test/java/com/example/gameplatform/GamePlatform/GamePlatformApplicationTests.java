package com.example.gameplatform.GamePlatform;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class GamePlatformApplicationTests {

	@Test
	void contextLoads() {
	}

}
