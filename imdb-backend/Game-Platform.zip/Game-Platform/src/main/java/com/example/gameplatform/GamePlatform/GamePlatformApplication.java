package com.example.gameplatform.GamePlatform;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class GamePlatformApplication {

	public static void main(String[] args) {
		SpringApplication.run(GamePlatformApplication.class, args);
	}

}
